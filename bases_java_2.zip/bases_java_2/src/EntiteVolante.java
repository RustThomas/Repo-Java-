public interface EntiteVolante {
    public void voler();
}